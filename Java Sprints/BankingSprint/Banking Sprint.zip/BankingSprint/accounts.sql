/*
-- Query: SELECT * FROM bankingsprint.accounts
LIMIT 0, 1000

-- Date: 2020-08-05 13:46
*/
INSERT INTO `` (`id`,`username`,`password`,`balance`,`name`) VALUES (1,'th','th',889,'Tristan Holloway');
INSERT INTO `` (`id`,`username`,`password`,`balance`,`name`) VALUES (2,'sa','sa',1271,'Samad-Aziz Choonara');
INSERT INTO `` (`id`,`username`,`password`,`balance`,`name`) VALUES (3,'lt','lt',942,'Lisakhanya Tshokolo');
INSERT INTO `` (`id`,`username`,`password`,`balance`,`name`) VALUES (4,'ob','ob',931,'Olwethu Bunyonyo');
INSERT INTO `` (`id`,`username`,`password`,`balance`,`name`) VALUES (5,'ah','ah',4534,'Aidan Holloway');
INSERT INTO `` (`id`,`username`,`password`,`balance`,`name`) VALUES (7,'gh','gh',777,'gh');
